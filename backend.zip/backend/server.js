require("dotenv").config();

const express = require("express");
const cors = require("cors");

const contactRoute = require("./routes/contact");
const companyLeadFormRoute = require("./routes/companyLeadForm");
const businessCaseRoute = require("./routes/businessCase");
const signalMinerContactRoute = require("./routes/Signalminercontact");
const requestDemoRoute = require("./routes/Requestdemo");
const cementWhitepaperRoute = require("./routes/Cementwhitepaper ");
const turnaroundsWhitepaperRoute = require("./routes/Turnaroundswhitepaper");
const metaverseWhitepaperRoute = require("./routes/Metaversewhitepaper ");
const vrtourRequestRoute = require("./routes/vrTourRequest "); // match your actual saved filename exactly
const renewableEnergyWhitepaperRoute = require("./routes/Renewableenergywhitepaper"); // match your actual saved filename exactly
const app = express();

/* ---------- CORS ---------- */
app.use(cors({
  origin: [
    "http://localhost:8080",
    "http://localhost:3000",
    "http://localhost:5173",
  ],
  credentials: true,
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowedHeaders: [
    "Content-Type",
    "Authorization",
    "ngrok-skip-browser-warning",
  ],
}));

app.use(express.json());

/* ---------- Routes ---------- */
app.use("/api/public/contact", contactRoute);
app.use("/api/public/company-lead-form", companyLeadFormRoute);
app.use("/api/public/business-case", businessCaseRoute);
app.use("/api/public/signal-miner-contact", signalMinerContactRoute);
app.use("/api/public/request-demo", requestDemoRoute);
app.use("/api/public/cement-whitepaper", cementWhitepaperRoute);
app.use("/api/public/turnarounds-whitepaper", turnaroundsWhitepaperRoute);
app.use("/api/public/metaverse-whitepaper", metaverseWhitepaperRoute);
app.use("/api/public/vr-tour-request", vrtourRequestRoute);
app.use("/api/public/renewable-energy-whitepaper", renewableEnergyWhitepaperRoute);
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});