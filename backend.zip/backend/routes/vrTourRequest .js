const express = require("express");
const nodemailer = require("nodemailer");

const router = express.Router();

const transporter = nodemailer.createTransport({
    service: "gmail",
    pool: true,
    maxConnections: 3,
    maxMessages: 100,
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    },
});

// Escapes user-supplied values before they land in the HTML email body.
function escapeHtml(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// Exactly 10 digits — matches the frontend's phone validation.
const PHONE_REGEX = /^\d{10}$/;

// Common free/personal email providers — rejected for a "Business Email" field.
const FREE_EMAIL_DOMAINS = new Set([
    "gmail.com",
    "yahoo.com",
    "hotmail.com",
    "outlook.com",
    "live.com",
    "aol.com",
    "icloud.com",
    "me.com",
    "mail.com",
    "protonmail.com",
    "proton.me",
    "yandex.com",
    "gmx.com",
    "zoho.com",
    "rediffmail.com",
]);

function isBusinessEmail(email) {
    const domain = email.split("@")[1]?.toLowerCase().trim();
    return !!domain && !FREE_EMAIL_DOMAINS.has(domain);
}

router.post("/", async (req, res) => {
    try {
        const {
            first_name,
            last_name,
            company_name,
            business_email,
            phone_number,
            message,
            source_page,
        } = req.body;

        // Required field validation (mirrors the frontend's `validate()`).
        if (
            !first_name ||
            !last_name ||
            !company_name ||
            !business_email ||
            !phone_number
        ) {
            return res.status(400).json({
                success: false,
                message: "Missing required fields",
            });
        }

        if (
            typeof first_name !== "string" ||
            typeof last_name !== "string" ||
            typeof company_name !== "string" ||
            typeof business_email !== "string" ||
            typeof phone_number !== "string" ||
            (message !== undefined && typeof message !== "string")
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid field types",
            });
        }

        const trimmedFirstName = first_name.trim();
        const trimmedLastName = last_name.trim();
        const trimmedCompanyName = company_name.trim();
        const trimmedEmail = business_email.trim();
        const trimmedPhone = phone_number.replace(/\D/g, "");
        const trimmedMessage = typeof message === "string" ? message.trim() : "";

        if (!EMAIL_REGEX.test(trimmedEmail)) {
            return res.status(400).json({
                success: false,
                message: "Enter a valid email address",
            });
        }

        if (!isBusinessEmail(trimmedEmail)) {
            return res.status(400).json({
                success: false,
                message: "Please use your business email address, not a personal one (e.g. Gmail, Yahoo)",
            });
        }

        if (!PHONE_REGEX.test(trimmedPhone)) {
            return res.status(400).json({
                success: false,
                message: "Enter a valid 10-digit phone number",
            });
        }

        const rows = [
            ["First name", trimmedFirstName],
            ["Last name", trimmedLastName],
            ["Company name", trimmedCompanyName],
            ["Business email", trimmedEmail],
            ["Phone number", trimmedPhone || "-"],
            ["Message", trimmedMessage || "-"],
            ["Source page", source_page || "-"],
        ];

        const tableRows = rows
            .map(
                ([label, value]) => `
                <tr>
                    <td style="padding:10px 14px;border:1px solid #e2e2e2;background:#f5f5f4;font-weight:600;white-space:nowrap;vertical-align:top;">${escapeHtml(
                        label
                    )}</td>
                    <td style="padding:10px 14px;border:1px solid #e2e2e2;">${escapeHtml(value)}</td>
                </tr>`
            )
            .join("");

        // Internal notification and the thank-you autoresponder are sent
        // concurrently — no reason to wait for one before starting the other.
        // The internal notification must succeed (it's awaited via Promise.all
        // below and will throw into the outer catch on failure). The thank-you
        // email is best-effort: if it fails, the submission still succeeds.
        const internalNotification = transporter.sendMail({
            from: process.env.EMAIL_USER,
            to: process.env.TO_EMAIL,
            replyTo: trimmedEmail,
            subject: `New VR Tour Request - ${trimmedFirstName} ${trimmedLastName} (${trimmedCompanyName})`,
            html: `
                <h2 style="font-family:sans-serif;">New VR Tour Request</h2>
                <table style="border-collapse:collapse;font-family:sans-serif;font-size:14px;width:100%;max-width:600px;">
                    <tbody>${tableRows}</tbody>
                </table>
            `,
        });

        const thankYouEmail = transporter
            .sendMail({
                from: process.env.EMAIL_USER,
                to: trimmedEmail,
                subject: "Your Visionaize VR Tour Request",
                html: `
                    <div style="font-family:sans-serif;max-width:600px;margin:0 auto;color:#0f2a4a;">
                        <h2 style="margin-bottom:4px;">Thanks, ${escapeHtml(trimmedFirstName)}!</h2>
                        <p style="font-size:14px;line-height:1.6;">
                            Thank you for requesting a Virtual Reality tour of an industrial
                            asset. Our team has received your request and will be in touch
                            shortly to set up your VR tour with Vizi.
                        </p>
                        <p style="font-size:14px;line-height:1.6;">
                            If you have any questions in the meantime, feel free to reply
                            directly to this email.
                        </p>
                        <p style="font-size:14px;line-height:1.6;margin-top:24px;">
                            — The Visionaize Team
                        </p>
                    </div>
                `,
            })
            .catch((autoReplyErr) => {
                console.error("Failed to send thank-you email to submitter:", autoReplyErr);
            });

        await Promise.all([internalNotification, thankYouEmail]);

        res.json({
            success: true,
            message: "Mail sent successfully",
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Unable to send mail",
        });
    }
});

module.exports = router;