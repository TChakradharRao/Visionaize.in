const express = require("express");
const nodemailer = require("nodemailer");

const router = express.Router();

const transporter = nodemailer.createTransport({
    service: "gmail",
    pool: true,
    maxConnections: 3,
    maxMessages: 100,
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    },
});

// Escapes user-supplied values before they land in the HTML email body.
function escapeHtml(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Maps a `source_page` path to the human-readable name used in the thank-you
// email, e.g. "/renewable-energy-whitepaper" -> "Renewable Energy Whitepaper".
// Add an entry here whenever this route gets reused from another page.
const SOURCE_PAGE_LABELS = {
    "/renewable-energy-whitepaper": "Renewable Energy Whitepaper",
    "/industries/renewables-energy": "Renewable Energy",
};

function sourcePageLabel(sourcePage) {
    if (!sourcePage) return "Visionaize";
    if (SOURCE_PAGE_LABELS[sourcePage]) return SOURCE_PAGE_LABELS[sourcePage];
    // Fallback: turn "/some-page-name" into "Some Page Name".
    return sourcePage
        .replace(/^\/+|\/+$/g, "")
        .split(/[-/]/)
        .filter(Boolean)
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ") || "Visionaize";
}

router.post("/", async (req, res) => {
    try {
        const {
            first_name,
            last_name,
            company,
            email,
            contact_me,
            source_page,
        } = req.body;

        // Required field validation (mirrors the frontend's form state).
        if (!first_name || !last_name || !company || !email) {
            return res.status(400).json({
                success: false,
                message: "Missing required fields",
            });
        }

        if (
            typeof first_name !== "string" ||
            typeof last_name !== "string" ||
            typeof company !== "string" ||
            typeof email !== "string" ||
            (source_page !== undefined && typeof source_page !== "string")
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid field types",
            });
        }

        const trimmedFirstName = first_name.trim();
        const trimmedLastName = last_name.trim();
        const trimmedCompany = company.trim();
        const trimmedEmail = email.trim();
        const wantsContact = Boolean(contact_me);
        const trimmedSourcePage = typeof source_page === "string" ? source_page.trim() : "";
        const pageLabel = sourcePageLabel(trimmedSourcePage);

        if (!EMAIL_REGEX.test(trimmedEmail)) {
            return res.status(400).json({
                success: false,
                message: "Enter a valid email address",
            });
        }

        const rows = [
            ["First name", trimmedFirstName],
            ["Last name", trimmedLastName],
            ["Company name", trimmedCompany],
            ["Business email", trimmedEmail],
            ["Wants a follow-up call", wantsContact ? "Yes" : "No"],
            ["Source page", `${pageLabel} (${trimmedSourcePage || "-"})`],
        ];

        const tableRows = rows
            .map(
                ([label, value]) => `
                <tr>
                    <td style="padding:10px 14px;border:1px solid #e2e2e2;background:#f5f5f4;font-weight:600;white-space:nowrap;vertical-align:top;">${escapeHtml(
                        label
                    )}</td>
                    <td style="padding:10px 14px;border:1px solid #e2e2e2;">${escapeHtml(value)}</td>
                </tr>`
            )
            .join("");

        // Internal notification and thank-you autoresponder are sent
        // concurrently. The internal notification must succeed; the
        // thank-you email is best-effort (its failure doesn't fail the request).
        const internalNotification = transporter.sendMail({
            from: process.env.EMAIL_USER,
            to: process.env.TO_EMAIL,
            replyTo: trimmedEmail,
            subject: `New Whitepaper Request (${pageLabel}) - ${trimmedFirstName} ${trimmedLastName} (${trimmedCompany})`,
            html: `
                <h2 style="font-family:sans-serif;">New ${escapeHtml(pageLabel)} Whitepaper Request</h2>
                <table style="border-collapse:collapse;font-family:sans-serif;font-size:14px;width:100%;max-width:600px;">
                    <tbody>${tableRows}</tbody>
                </table>
            `,
        });

        const thankYouEmail = transporter
            .sendMail({
                from: process.env.EMAIL_USER,
                to: trimmedEmail,
                subject: `Your ${pageLabel} Whitepaper from Visionaize`,
                html: `
                    <div style="font-family:sans-serif;max-width:600px;margin:0 auto;color:#0f2a4a;">
                        <h2 style="margin-bottom:4px;">Thanks, ${escapeHtml(trimmedFirstName)}!</h2>
                        <p style="font-size:14px;line-height:1.6;">
                            Thank you for requesting the <strong>${escapeHtml(pageLabel)}</strong>
                            whitepaper from Visionaize.
                        </p>
                        <p style="font-size:14px;line-height:1.6;">
                            You will receive the whitepaper copy shortly in your email inbox.
                        </p>
                        ${
                            wantsContact
                                ? `<p style="font-size:14px;line-height:1.6;">
                                        You've asked for a Digital Twin expert to reach out — we'll be in touch shortly.
                                   </p>`
                                : ""
                        }
                        // <p style="font-size:14px;line-height:1.6;">
                        //     If you have any questions in the meantime, feel free to reply
                        //     directly to this email.
                        // </p>
                        <p style="font-size:14px;line-height:1.6;margin-top:24px;">
                            — The Visionaize Team
                        </p>
                    </div>
                `,
            })
            .catch((autoReplyErr) => {
                console.error("Failed to send thank-you email to submitter:", autoReplyErr);
            });

        await Promise.all([internalNotification, thankYouEmail]);

        res.json({
            success: true,
            message: "Mail sent successfully",
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Unable to send mail",
        });
    }
});

module.exports = router;