const express = require("express");
const nodemailer = require("nodemailer");

const router = express.Router();

const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    },
});

router.post("/", async (req, res) => {
    try {
        const {
            name,
            email,
            company,
            target_capacity_bpd,
            actual_output_bpd,
            location,
            planned_downtime_yearly,
            unplanned_downtime_yearly,
            implementation_schedule,
            time_spent_on_data_pct,
            use_cases,
            other_use_cases,
            source_page,
        } = req.body;

        if (!name || !email || !company) {
            return res.status(400).json({
                success: false,
                message: "Missing required fields",
            });
        }

        const useCasesList =
            Array.isArray(use_cases) && use_cases.length > 0
                ? `<ul style="margin:0;padding-left:18px;">${use_cases
                      .map((uc) => `<li>${uc}</li>`)
                      .join("")}</ul>`
                : "-";

        const rows = [
            ["Name", name],
            ["Email", email],
            ["Company", company],
            ["Target capacity (BPD)", target_capacity_bpd || "-"],
            ["Actual output (BPD)", actual_output_bpd || "-"],
            ["Location", location || "-"],
            ["Planned downtime (yearly)", planned_downtime_yearly || "-"],
            ["Unplanned downtime (yearly)", unplanned_downtime_yearly || "-"],
            ["Implementation schedule", implementation_schedule || "-"],
            ["Time spent on data (%)", time_spent_on_data_pct || "-"],
            ["Use cases", useCasesList],
            ["Other use cases", other_use_cases || "-"],
            ["Source page", source_page || "-"],
        ];

        const tableRows = rows
            .map(
                ([label, value]) => `
                <tr>
                    <td style="padding:10px 14px;border:1px solid #e2e2e2;background:#f5f5f4;font-weight:600;white-space:nowrap;vertical-align:top;">${label}</td>
                    <td style="padding:10px 14px;border:1px solid #e2e2e2;">${value}</td>
                </tr>`
            )
            .join("");

        await transporter.sendMail({
            from: process.env.EMAIL_USER,
            to: process.env.TO_EMAIL,
            subject: `New Business Case Submission - ${name} (${company})`,
            html: `
                <h2 style="font-family:sans-serif;">New Business Case Request</h2>
                <table style="border-collapse:collapse;font-family:sans-serif;font-size:14px;width:100%;max-width:600px;">
                    <tbody>${tableRows}</tbody>
                </table>
            `,
        });

        res.json({
            success: true,
            message: "Mail sent successfully",
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Unable to send mail",
        });
    }
});

module.exports = router;