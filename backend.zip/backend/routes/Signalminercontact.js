const express = require("express");
const nodemailer = require("nodemailer");

const router = express.Router();

const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    },
});

// Escapes user-supplied values before they land in the HTML email body.
function escapeHtml(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

router.post("/", async (req, res) => {
    try {
        const {
            first_name,
            last_name,
            company,
            title,
            phone_number,
            email,
            seeking_solutions,
            comments,
            source_page,
        } = req.body;

        if (!first_name || !last_name || !company || !title || !email) {
            return res.status(400).json({
                success: false,
                message: "Missing required fields",
            });
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({
                success: false,
                message: "Enter a valid email address",
            });
        }

        const solutionsList =
            Array.isArray(seeking_solutions) && seeking_solutions.length > 0
                ? `<ul style="margin:0;padding-left:18px;">${seeking_solutions
                      .map((s) => `<li>${escapeHtml(s)}</li>`)
                      .join("")}</ul>`
                : "-";

        const rows = [
            ["First name", first_name],
            ["Last name", last_name],
            ["Company", company],
            ["Title", title],
            ["Phone number", phone_number || "-"],
            ["Email", email],
            ["Seeking solutions for", solutionsList],
            ["Comments", comments || "-"],
            ["Source page", source_page || "-"],
        ];

        const tableRows = rows
            .map(
                ([label, value]) => `
                <tr>
                    <td style="padding:10px 14px;border:1px solid #e2e2e2;background:#f5f5f4;font-weight:600;white-space:nowrap;vertical-align:top;">${escapeHtml(
                        label
                    )}</td>
                    <td style="padding:10px 14px;border:1px solid #e2e2e2;">${
                        label === "Seeking solutions for" ? value : escapeHtml(value)
                    }</td>
                </tr>`
            )
            .join("");

        await transporter.sendMail({
            from: process.env.EMAIL_USER,
            to: process.env.TO_EMAIL,
            replyTo: email,
            subject: `New Signal Miner Contact Request - ${first_name} ${last_name} (${company})`,
            html: `
                <h2 style="font-family:sans-serif;">New Signal Miner Contact Request</h2>
                <table style="border-collapse:collapse;font-family:sans-serif;font-size:14px;width:100%;max-width:600px;">
                    <tbody>${tableRows}</tbody>
                </table>
            `,
        });

        res.json({
            success: true,
            message: "Mail sent successfully",
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Unable to send mail",
        });
    }
});

module.exports = router;