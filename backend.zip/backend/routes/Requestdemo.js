const express = require("express");
const nodemailer = require("nodemailer");

const router = express.Router();

const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    },
});

// Escapes user-supplied values before they land in the HTML email body.
function escapeHtml(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_REGEX = /^\d{10}$/;

// Common free/personal email providers — reject these for a "Business Email" field.
const FREE_EMAIL_DOMAINS = new Set([
    "gmail.com",
    "yahoo.com",
    "hotmail.com",
    "outlook.com",
    "live.com",
    "aol.com",
    "icloud.com",
    "me.com",
    "mail.com",
    "protonmail.com",
    "proton.me",
    "yandex.com",
    "gmx.com",
    "zoho.com",
    "rediffmail.com",
]);

function isBusinessEmail(email) {
    const domain = email.split("@")[1]?.toLowerCase().trim();
    return !!domain && !FREE_EMAIL_DOMAINS.has(domain);
}

router.post("/", async (req, res) => {
    try {
        const { name, email, company, phone, message, source_page } = req.body;

        if (!name || !email || !phone) {
            return res.status(400).json({
                success: false,
                message: "Missing required fields",
            });
        }

        if (!EMAIL_REGEX.test(email)) {
            return res.status(400).json({
                success: false,
                message: "Enter a valid email address",
            });
        }

        if (!isBusinessEmail(email)) {
            return res.status(400).json({
                success: false,
                message: "Please use your business email address, not a personal one (e.g. Gmail, Yahoo)",
            });
        }

        if (!PHONE_REGEX.test(phone)) {
            return res.status(400).json({
                success: false,
                message: "Enter a valid 10-digit phone number",
            });
        }

        const rows = [
            ["Name", name],
            ["Email", email],
            ["Company", company || "-"],
            ["Phone", phone],
            ["Area of interest", message || "-"],
            ["Source page", source_page || "-"],
        ];

        const tableRows = rows
            .map(
                ([label, value]) => `
                <tr>
                    <td style="padding:10px 14px;border:1px solid #e2e2e2;background:#f5f5f4;font-weight:600;white-space:nowrap;vertical-align:top;">${escapeHtml(
                        label
                    )}</td>
                    <td style="padding:10px 14px;border:1px solid #e2e2e2;">${escapeHtml(value)}</td>
                </tr>`
            )
            .join("");

        // Internal notification — goes to the sales/team inbox.
        await transporter.sendMail({
            from: process.env.EMAIL_USER,
            to: process.env.TO_EMAIL,
            replyTo: email,
            subject: `New Demo Request - ${name}${company ? ` (${company})` : ""}`,
            html: `
                <h2 style="font-family:sans-serif;">New Request a Demo Submission</h2>
                <table style="border-collapse:collapse;font-family:sans-serif;font-size:14px;width:100%;max-width:600px;">
                    <tbody>${tableRows}</tbody>
                </table>
            `,
        });

        // Thank-you autoresponder — goes back to the person who submitted the form.
        // Sent best-effort: if this fails, the submission itself still succeeds.
        try {
            await transporter.sendMail({
                from: process.env.EMAIL_USER,
                to: email,
                subject: "Thanks for your interest in Visionaize",
                html: `
                    <div style="font-family:sans-serif;max-width:600px;margin:0 auto;color:#0f2a4a;">
                        <h2 style="margin-bottom:4px;">Thanks, ${escapeHtml(name.split(" ")[0] || name)}!</h2>
                        <p style="font-size:14px;line-height:1.6;">
                            We've received your request for a Visionaize demo and one of our
                            team members will reach out to you shortly to schedule a time.
                        </p>
                        <p style="font-size:14px;line-height:1.6;">
                            In the meantime, if you have any questions, feel free to reply
                            directly to this email.
                        </p>
                        <p style="font-size:14px;line-height:1.6;margin-top:24px;">
                            — The Visionaize Team
                        </p>
                    </div>
                `,
            });
        } catch (autoReplyErr) {
            console.error("Failed to send thank-you email to submitter:", autoReplyErr);
        }

        res.json({
            success: true,
            message: "Mail sent successfully",
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Unable to send mail",
        });
    }
});

module.exports = router;