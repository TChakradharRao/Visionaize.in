const express = require("express");
const nodemailer = require("nodemailer");

const router = express.Router();

const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    },
});

// Escapes user-supplied values before they land in the HTML email body.
function escapeHtml(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Common free/personal email providers — reject these for a "Business Email" field.
const FREE_EMAIL_DOMAINS = new Set([
    "gmail.com",
    "yahoo.com",
    "hotmail.com",
    "outlook.com",
    "live.com",
    "aol.com",
    "icloud.com",
    "me.com",
    "mail.com",
    "protonmail.com",
    "proton.me",
    "yandex.com",
    "gmx.com",
    "zoho.com",
    "rediffmail.com",
]);

function isBusinessEmail(email) {
    const domain = email.split("@")[1]?.toLowerCase().trim();
    return !!domain && !FREE_EMAIL_DOMAINS.has(domain);
}

router.post("/", async (req, res) => {
    try {
        const {
            first_name,
            last_name,
            company,
            email,
            contact_me,
            source_page,
        } = req.body;

        if (!first_name || !last_name || !company || !email) {
            return res.status(400).json({
                success: false,
                message: "Missing required fields",
            });
        }

        if (!EMAIL_REGEX.test(email)) {
            return res.status(400).json({
                success: false,
                message: "Enter a valid email address",
            });
        }

        if (!isBusinessEmail(email)) {
            return res.status(400).json({
                success: false,
                message: "Please use your business email address, not a personal one (e.g. Gmail, Yahoo)",
            });
        }

        const rows = [
            ["First name", first_name],
            ["Last name", last_name],
            ["Company", company],
            ["Email", email],
            ["Wants expert contact", contact_me ? "Yes" : "No"],
            ["Source page", source_page || "-"],
        ];

        const tableRows = rows
            .map(
                ([label, value]) => `
                <tr>
                    <td style="padding:10px 14px;border:1px solid #e2e2e2;background:#f5f5f4;font-weight:600;white-space:nowrap;vertical-align:top;">${escapeHtml(
                        label
                    )}</td>
                    <td style="padding:10px 14px;border:1px solid #e2e2e2;">${escapeHtml(value)}</td>
                </tr>`
            )
            .join("");

        // Internal notification — goes to the sales/team inbox.
        await transporter.sendMail({
            from: process.env.EMAIL_USER,
            to: process.env.TO_EMAIL,
            replyTo: email,
            subject: `New Cement Whitepaper Request - ${first_name} ${last_name} (${company})`,
            html: `
                <h2 style="font-family:sans-serif;">New Cement Industry Whitepaper Request</h2>
                <table style="border-collapse:collapse;font-family:sans-serif;font-size:14px;width:100%;max-width:600px;">
                    <tbody>${tableRows}</tbody>
                </table>
            `,
        });

        // Thank-you autoresponder — goes back to the person who submitted the form.
        // Sent best-effort: if this fails, the submission itself still succeeds.
        try {
            await transporter.sendMail({
                from: process.env.EMAIL_USER,
                to: email,
                subject: "Your Visionaize Cement Industry Whitepaper",
                html: `
                    <div style="font-family:sans-serif;max-width:600px;margin:0 auto;color:#0f2a4a;">
                        <h2 style="margin-bottom:4px;">Thanks, ${escapeHtml(first_name)}!</h2>
                        <p style="font-size:14px;line-height:1.6;">
                            Thank you for your interest in the Visionaize Cement Industry
                            Whitepaper. Our team has received your request${
                                contact_me
                                    ? " and a Digital Twin expert will reach out to you shortly."
                                    : "."
                            }
                        </p>
                        <p style="font-size:14px;line-height:1.6;">
                            If you have any questions in the meantime, feel free to reply
                            directly to this email.
                        </p>
                        <p style="font-size:14px;line-height:1.6;margin-top:24px;">
                            — The Visionaize Team
                        </p>
                    </div>
                `,
            });
        } catch (autoReplyErr) {
            console.error("Failed to send thank-you email to submitter:", autoReplyErr);
        }

        res.json({
            success: true,
            message: "Mail sent successfully",
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Unable to send mail",
        });
    }
});

module.exports = router;